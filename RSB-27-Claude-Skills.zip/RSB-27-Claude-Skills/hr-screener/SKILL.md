---
name: hr-screener
description: Writes targeted job descriptions, candidate screening criteria, interview question banks, resume evaluation rubrics, and offer letters. Replaces HR screening and talent acquisition teams. Use whenever writing a job description, screening candidates, building an interview process, evaluating resumes, or creating hiring documentation. Trigger on any mention of hiring, job description, JD, resume screening, interview questions, candidate evaluation, or talent acquisition.
---

# HR Screener Skill

Replaces a team of 200 HR screeners and talent acquisition specialists. Writes job descriptions that attract the right people and filters that surface the best candidates without bias.

---

## The Job Description Formula

Most JDs attract the wrong people because they describe a role, not an outcome. Write JDs from the outcome backward.

```
SECTION 1: The One-Line Hook (not a title, a result)
SECTION 2: What Success Looks Like in 90 Days
SECTION 3: What You Will Actually Do (not a duty list — a story)
SECTION 4: What We Need From You (must-haves only, keep under 5)
SECTION 5: What You Will Get (be specific, not "competitive salary")
SECTION 6: Who Should Not Apply (this is the most underused section)
```

### Section 1: The Hook

Wrong: "We are looking for a Senior Product Manager to join our growing team."
Right: "You will own the payments vertical at a Series B fintech and take it from Rs 50L to Rs 5Cr ARR in 18 months."

The hook must name the specific outcome, not the role category.

### Section 2: 90-Day Success

```
By Day 30: [Specific deliverable or understanding]
By Day 60: [First meaningful contribution]
By Day 90: [Measurable outcome]
```

This tells the candidate what winning looks like. It also filters out people who cannot commit to specifics.

### Section 3: What You Will Actually Do

Write this in first person from the candidate's perspective:

```
"You will own the customer onboarding flow end to end."
"You will run weekly sprint planning with a team of 4 engineers."
"You will make the call on which features ship and which get cut."
```

Never: A bulleted list of vague duties starting with "Responsible for..."

### Section 4: Must-Haves

Keep this to 5 items maximum. Every requirement above 5 filters out a good candidate unnecessarily.

For each must-have, state why it matters:

```
Must have: [Requirement] — because [specific reason this role needs it]
```

Example:
```
Must have: 3 plus years working on consumer products with more than 100K DAU — because you need to have felt what scale does to a simple product decision.
```

### Section 5: What You Get

Be specific or say nothing.

```
Wrong: "Competitive salary and equity"
Right: "Rs 25 to 35 lakh base. 0.5 to 1 percent ESOP on a 4-year vest. Full remote. Rs 50K learning budget per year."
```

Vague compensation language signals you are either embarrassed by the number or do not know it yet. Both are bad signals to a good candidate.

### Section 6: Who Should Not Apply

This is optional but powerful for roles where fit matters as much as skill.

```
"This role is probably wrong for you if:
You prefer clear processes over building them.
You need a manager who checks in daily to feel supported.
You are more comfortable maintaining than building."
```

---

## Resume Screening Rubric

Use this scoring system for consistency across screeners.

```
SIGNAL 1: Specificity of impact (0 to 3 points)
0: No numbers or outcomes mentioned
1: Vague outcomes ("improved performance", "led team")
2: Numbers without context ("increased revenue 40%")
3: Numbers with context and method ("increased checkout conversion 40% by removing 2 form fields and A/B testing payment copy")

SIGNAL 2: Trajectory (0 to 2 points)
0: Lateral or downward moves without explanation
1: Upward moves within organisations
2: Increasing scope and ownership across roles

SIGNAL 3: Relevance (0 to 2 points)
0: Domain mismatch
1: Adjacent domain with transferable skills
2: Direct domain experience

SIGNAL 4: Red flag check (-1 per flag)
Gap of more than 6 months without explanation
More than 3 companies in 4 years without progression explanation
Claims that cannot be verified or seem inflated

TOTAL: 7 points maximum
6 to 7: Strong hire
4 to 5: Worth an interview
Below 4: Pass unless strong referral
```

---

## Interview Question Bank

### For Any Role — The 5 Questions That Reveal Everything

```
Question 1: Tell me about the most complex problem you have solved.
What you are testing: How they think, not what they know.
Green flag: They explain the problem clearly, describe their process, admit what they got wrong.
Red flag: The story has no friction. Everything worked perfectly.

Question 2: Tell me about a time you disagreed with your manager and what happened.
What you are testing: Intellectual honesty and how they handle authority.
Green flag: They stood their ground with data, the outcome varied.
Red flag: They always agreed or always fought and always won.

Question 3: What is the most important thing you learned in your last role that you would do differently in this one?
What you are testing: Self-awareness and growth mindset.
Green flag: Specific, honest, something they actually changed.
Red flag: Generic answer about "communication" or "time management."

Question 4: What does your ideal manager do that your worst manager did not?
What you are testing: What kind of environment they need to succeed.
Green flag: Specific behaviours with real examples.
Red flag: "I like to be left alone" with no further context.

Question 5: What are you working on outside of work?
What you are testing: Curiosity and self-direction.
Green flag: Anything specific — a project, a book, a skill.
Red flag: Nothing or a rehearsed-sounding hobby.
```

---

## Offer Letter Formula

```
OFFER LETTER STRUCTURE:

Opening: [Candidate name], we would like to offer you the position of [role] at [company].

Compensation:
Base salary: Rs [X] per annum, paid monthly
Variable component: Rs [X] per annum on achievement of [specific targets]
Equity: [X]% ESOP on [X]-year vest with [X]-month cliff
Joining bonus: Rs [X] (if applicable)

Benefits:
[List specifically. Do not say "standard benefits."]

Start date: [Specific date]
Reporting to: [Name and title]

This offer is contingent on:
[List only real contingencies: background check, reference check, existing NDA review]

Offer expires: [Specific date — 5 to 7 business days is standard]

We are genuinely excited to work with you. If you have any questions before deciding, contact [name] at [contact].
```
