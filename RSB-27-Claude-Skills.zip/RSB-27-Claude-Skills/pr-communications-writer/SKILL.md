---
name: pr-communications-writer
description: Writes press releases, crisis communications, executive statements, media pitches, company announcements, and internal communications for organisations. Replaces PR and corporate communications teams. Use whenever writing a press release, crisis statement, media pitch, executive quote, company announcement, or internal communication to employees. Trigger on any mention of press release, PR, media pitch, crisis communication, company announcement, executive statement, or corporate communications.
---

# PR and Communications Writer Skill

Replaces a team of 300 PR and communications professionals. Writes press releases, crisis responses, media pitches, and executive communications that read like they came from a senior communications director.

---

## The Core Principle

All communications have one job: control the narrative before someone else does.

Waiting to communicate is not caution. It is ceding the floor to whoever fills the silence first.

---

## Press Release Formula

```
FOR IMMEDIATE RELEASE (or EMBARGO UNTIL [date/time])

HEADLINE: [The news in one sentence. Verb must be in the headline.]
SUBHEADLINE: [One sentence expanding the headline with the most relevant context]

[CITY, Date] — [Company Name], [one-line description of company], today announced [the news in plain language].

PARAGRAPH 1 (The Lead):
Who, what, when, where, why. All five in 40 to 60 words.
The most important information goes here, not at the end.

PARAGRAPH 2 (The Context):
Why this matters. Market context, problem being solved, timing.

PARAGRAPH 3 (The Quote):
"[Authentic quote from senior executive]," said [Name], [Title], [Company].
"[Second sentence that adds information, not just enthusiasm]."

PARAGRAPH 4 (The Details):
Specific numbers, dates, product details, or partnership terms.
Anything a journalist needs to write the story.

PARAGRAPH 5 (The Boilerplate):
About [Company Name]: [3 to 4 sentences on what the company does, founding year, size, notable customers or investors]

MEDIA CONTACT:
[Name]
[Title]
[Email]
[Phone]
```

### Headline Rules

Every press release headline must:
- Contain an active verb
- Name the company or person doing something
- State the outcome, not the action

Wrong: "XYZ Company Announces Partnership with ABC Corp"
Right: "XYZ and ABC Partner to Cut Indian SME Loan Processing Time From 14 Days to 4 Hours"

The wrong version is what happened. The right version is why it matters.

---

## Crisis Communication Framework

Use the ACRE method for all crisis communications:

```
A — Acknowledge (what happened, to whom, when)
C — Care (what you feel about the people affected)
R — Remediate (what you are doing about it right now)
E — Ensure (what you are doing to prevent recurrence)
```

### The First Hour Statement

This goes out within the first hour of a crisis becoming public. It does not have all the answers. That is fine.

```
[Company Name] Statement on [Issue]

We are aware of [specific issue].

We understand that [X people / customers / employees] have been affected. We take this seriously.

Our team is [specific action being taken right now].

We will provide a full update by [specific time] today.

[Contact for media]
[Contact for affected parties]
```

The first hour statement does not require you to have answers. It requires you to demonstrate you are treating the situation with urgency.

### The Full Crisis Response (within 24 hours)

```
PARAGRAPH 1: What happened — plainly, without euphemism
"On [date], [specific thing occurred]. This affected [number] of our [customers/employees/users]."

PARAGRAPH 2: The cause — honestly stated
"This occurred because [root cause]. We should have [what should have been done differently]."

PARAGRAPH 3: Who is affected and how
"[Specific group] experienced [specific impact]. We have directly contacted [X%] of affected parties."

PARAGRAPH 4: What has been done
"[Specific remediation steps taken]. As of [time], [specific status]."

PARAGRAPH 5: What will be done to prevent recurrence
"We are [specific process/system/policy change]. This will be completed by [date]."

PARAGRAPH 6: What affected parties receive
"All affected [customers/users/employees] will receive [specific thing — credit, replacement, compensation]."

PARAGRAPH 7: Contact
"For questions, contact [name] at [email]. We will update this statement as new information becomes available."

[Name]
[Title]
[Date and time of statement]
```

What never to write in a crisis:
- "We apologize for any inconvenience" — minimises the harm
- "We take this very seriously" without specific action following immediately
- "We cannot comment on specific cases" — this is for legal situations only, not general communications
- Passive voice when describing what happened ("mistakes were made")

---

## Media Pitch Formula

A media pitch gets a journalist to write about you. It is not a press release. It is a tip.

```
Subject: [The story angle in one line — not your company name]

[Journalist's name],

[One sentence on a trend or event happening right now that is relevant to their beat]

[Company X] is a [relevant description] that is [specific thing they are doing related to that trend].

The story angle I think is interesting for your readers: [One specific story idea, not a company overview]

Supporting numbers: [2 to 3 specific data points that make the story real]

Happy to set up a 15-minute call with [executive name] who can [specific thing they can offer — data, exclusive, first look at something].

[Name]
[Contact]
```

The pitch is about the story, not the company. Journalists do not care about your product launch. They care about the story their readers need to hear and whether you can help them tell it.

---

## Executive Statement Formula

When a senior leader needs to say something publicly:

```
[What I believe about this issue — stated directly]

[Why I believe it — one specific reason, one specific example]

[What this means for [relevant group — customers, employees, industry]]

[What we are doing or will do as a result]
```

Keep executive statements under 150 words. Longer means the point is unclear.

---

## Internal Communication Formula

For company-wide announcements to employees:

```
Subject: [What changed] — [Who is affected]

[What is happening] — stated in the first sentence, not the last.

[Why this is happening] — honest, specific, not corporate-speak.

[What changes for employees] — specific, with dates.

[What does not change] — often more reassuring than what does change.

[What employees should do] — one specific action if needed.

[Where to ask questions] — a real person, not "HR".

[Name]
[Date]
```

The most common failure in internal communications is burying the news in three paragraphs of context. Employees notice this and it erodes trust faster than the news itself would have.

---

## Tone by Situation

```
Product launch: Confident, specific, outcome-focused
Funding announcement: Excited but grounded — state what the money is for
Crisis: Sober, direct, action-oriented — no marketing language
Leadership change: Respectful of the past, specific about the future
Policy change: Clear on what changes, clear on why, clear on the date
Bad financial results: Honest about what happened, specific about what changes
```

Match the tone to the situation. Using product launch energy for a crisis is the fastest way to turn a manageable situation into a reputational disaster.
