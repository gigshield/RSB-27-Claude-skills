---
name: training-developer
description: Creates employee onboarding programmes, training manuals, e-learning scripts, assessment questions, and learning objectives. Converts subject matter expert knowledge into structured learning experiences. Trigger on any request for training materials, onboarding content, e-learning script, training manual, learning objectives, or employee training programme.
---
# Training Developer Skill
Replaces 1M training and L&D professionals globally. Converts knowledge into structured learning that produces competent employees.

## Learning Design Principle
Training fails when it transfers information. Training succeeds when it changes behaviour.

Before creating any training, answer: "What will the learner DO differently after this?"
If you cannot answer that in one sentence, the training has no clear purpose.

## Training Programme Structure
```
PROGRAMME TITLE: [Name]
TARGET AUDIENCE: [Role, experience level, prior knowledge]
LEARNING OBJECTIVES: By the end of this programme, the learner will be able to:
  1. [Observable skill — verb + outcome]
  2. [Observable skill]
  3. [Observable skill]
DURATION: [Total hours]
FORMAT: [In-person / online / blended]
ASSESSMENT METHOD: [How competency is verified]

MODULE BREAKDOWN:
Module 1: [Topic] — [Duration] — [Objective it covers]
Module 2: [Topic] — [Duration] — [Objective it covers]
```

## Learning Objective Formula
Use Bloom's Taxonomy verbs. Weak objectives use vague verbs.

```
WEAK: "Understand the sales process"
STRONG: "Apply the 5-step SPIN selling framework in a live customer call"

WEAK: "Know company policy"
STRONG: "Identify the 3 situations that require HR escalation before taking action"

Bloom's verbs by level:
Remember: list, name, recall, recognise
Understand: describe, explain, summarise
Apply: use, demonstrate, execute, implement
Analyse: compare, differentiate, examine, break down
Evaluate: assess, justify, argue, recommend
Create: design, build, produce, develop
```

## Onboarding Programme (First 90 Days)
```
DAY 1 — ORIENTATION
Morning: Company history, mission, values (30 min — not longer)
Afternoon: System access, tools setup, first project overview
End of day 1 goal: The new hire knows who to ask for what

WEEK 1 — IMMERSION
Monday: Direct team, their roles, how decisions are made
Tuesday to Thursday: Product/service deep dive. They use it, not just learn about it.
Friday: Shadow 3 customer interactions (support calls, sales calls, or internal meetings)
End of week 1 goal: The new hire can describe what the company does to a stranger

WEEKS 2 TO 4 — PRACTICE
Supervised execution of core tasks with immediate feedback
Daily check-in (10 minutes): What went well, what was unclear
End of month 1 goal: The new hire completes core tasks independently with low error rate

MONTHS 2 TO 3 — CONTRIBUTION
Take ownership of one small project or recurring task
Peer teaching: they explain one thing they learned to a colleague
30-day and 60-day reviews with specific feedback
End of day 90 goal: The new hire is net positive to the team
```

## Assessment Question Design
```
KNOWLEDGE CHECK (multiple choice):
Question stem: a situation, not just a fact
"A customer says they never received their order but tracking shows delivered. You should:"
Options: One clearly correct, one common wrong answer, two plausible distractors
Avoid: "all of the above" / "none of the above"

SKILL CHECK (scenario):
"You receive an invoice for Rs 50,000 but the PO was for Rs 45,000. Walk through your steps."
Good answers: specific sequence of actions
Weak answers: vague general statements

COMPETENCY CHECK (observation):
Define what "good looks like" before observing
Rate on 1-3 scale: Not yet / Developing / Competent
Provide evidence, not opinion: "They did X but missed Y"
```
