---
name: contract-reviewer
description: Reviews contracts, vendor agreements, NDAs, employment agreements, and SaaS terms for red flags, negotiation points, missing clauses, and risk assessment. Replaces junior legal associates for first-pass contract review. Use whenever reviewing a contract, vendor agreement, NDA, terms of service, employment contract, or partnership agreement. Trigger on any mention of contract review, NDA, vendor agreement, legal review, terms, clause analysis, or contract red flag.
---

# Contract Reviewer Skill

Replaces a team of 300 junior legal associates for first-pass contract review. Identifies red flags, negotiation leverage, missing standard clauses, and risk ratings before legal counsel reviews.

IMPORTANT: This skill produces a first-pass review for informed decision-making. It does not replace qualified legal counsel for final decisions on material contracts. Always note this to the person requesting the review.

---

## The Review Framework

Every contract review covers 7 areas in this order:

```
Area 1: Parties and Authority
Area 2: Core Commercial Terms
Area 3: Intellectual Property
Area 4: Liability and Indemnification
Area 5: Termination Rights
Area 6: Dispute Resolution
Area 7: Missing Standard Clauses
```

---

## Area 1: Parties and Authority

Check:
- Are the correct legal entities named (not trading names)?
- Is the signatory authorized to bind the company?
- If a subsidiary is signing, is there a parent guarantee?
- Are all parties correctly defined throughout the document?

Red flag: Vague party descriptions. "The Company" with no clear definition of which entity.

---

## Area 2: Core Commercial Terms

For every contract, extract and state clearly:

```
Contract value: [Total value or rate]
Payment terms: [When payment is due, in what form]
Delivery obligations: [What each party must do and by when]
Performance standards: [SLAs, acceptance criteria, quality standards]
Price adjustment: [Can prices change? Under what conditions?]
Auto-renewal: [Yes/No. If yes, notice period to cancel]
```

Red flags in commercial terms:
- Unilateral price increases without notice period
- Auto-renewal with notice periods under 30 days
- No acceptance criteria for deliverables
- Payment terms longer than 90 days for services
- Performance obligations on one side only

---

## Area 3: Intellectual Property

The most commonly disputed area. Check all of these:

```
Who owns work created under this contract?
[Should be: work for hire belongs to the paying party for custom development]

Who owns pre-existing IP that one party brings to the engagement?
[Should be: each party retains ownership of their pre-existing IP]

Are there licence grants? If so:
- What is the scope (exclusive or non-exclusive)?
- What is the term (perpetual or time-limited)?
- What is the territory (global or specific regions)?
- Can sublicences be granted?

Who owns improvements and derivatives?
[This is often where disputes arise. It should be explicitly addressed.]

Is there a background IP licence needed for the contract to function?
```

Red flags in IP:
- "All work product is assigned to [Counterparty]" with no carve-out for pre-existing IP
- Exclusive licences where non-exclusive would suffice
- No reversion of IP if the contract is terminated for breach by the counterparty
- Open-ended IP assignment language

---

## Area 4: Liability and Indemnification

```
Limitation of liability:
Is there a cap on total liability? [Standard: 12 months of fees paid]
Are there carve-outs that remove the cap? [Death, fraud, wilful misconduct are standard]
Does the cap apply equally to both parties or only one?

Indemnification:
Which party indemnifies for what?
Is there a mutual indemnification or one-way?
Third-party IP infringement indemnification — who bears this?
Data breach indemnification — is it present? Is it fair?

Consequential damages:
Are consequential, indirect, or punitive damages excluded?
[Standard market position: both parties exclude consequential damages]
Are there carve-outs to the exclusion? [Data breaches often carve out]
```

Red flags in liability:
- No liability cap at all (unlimited liability exposure)
- Liability cap that only applies to one party
- One-sided indemnification without reciprocity
- No mutual exclusion of consequential damages

---

## Area 5: Termination Rights

```
Termination for cause:
What triggers a right to terminate for cause?
What is the cure period before termination takes effect? [Standard: 30 days]
Is there a right to terminate for insolvency of the other party?

Termination for convenience:
Can either party terminate without cause?
What is the notice period? [Standard: 30 to 90 days depending on contract value]
Is there a payment obligation for termination for convenience?

Effect of termination:
What happens to work in progress on termination?
What data or materials must be returned or destroyed?
Are there survival clauses? (IP, confidentiality, liability provisions should survive)
Post-termination restrictions — are they reasonable in scope and duration?
```

Red flags in termination:
- No right to terminate for convenience (locked in indefinitely)
- Cure period shorter than 14 days
- Punitive termination fees
- No data return obligation on termination

---

## Area 6: Dispute Resolution

```
Governing law: [Which country/state's law applies]
Jurisdiction: [Which courts have jurisdiction]
Dispute escalation: [Is there a mediation or escalation requirement before litigation?]
Arbitration: [Is arbitration specified? If so, which body, which seat?]
```

Check for Indian-specific considerations:
- If the contract is with an Indian party, Arbitration and Conciliation Act 1996 applies
- SEBI or RBI regulation may constrain terms for regulated entities
- Stamp duty requirements vary by state

Red flags in dispute resolution:
- Jurisdiction in a foreign country with no explanation
- Arbitration clauses that are one-sided (counterparty picks the arbitrator)
- No escalation process before expensive arbitration

---

## Area 7: Missing Standard Clauses

Check if these are present. Flag as missing if not.

```
Confidentiality: [Should be mutual and survive termination]
Force majeure: [Should include pandemics, cyber incidents, regulatory changes]
Non-solicitation: [Standard for service agreements — scope and term matter]
Data protection: [Mandatory if personal data is processed — PDPB compliance for India]
Assignment: [Can either party assign without consent? Standard: no, with exceptions for M&A]
Entire agreement: [Should be present to avoid disputes about prior representations]
Severability: [Standard. If one clause is unenforceable, rest of contract survives]
Amendment process: [Should require written agreement by both parties]
Notices: [Who receives notices and by what method]
```

---

## Risk Rating Output

End every contract review with this summary:

```
CONTRACT RISK RATING: [Critical / High / Medium / Low]

Critical: Do not sign without legal counsel review and material changes
High: Significant issues require negotiation before signing
Medium: Issues present but manageable with minor amendments
Low: Standard market terms, minor points to note

TOP 3 ISSUES IN PRIORITY ORDER:
1. [Issue — Clause — Risk — Recommended fix]
2. [Issue — Clause — Risk — Recommended fix]
3. [Issue — Clause — Risk — Recommended fix]

RECOMMENDED NEXT STEP:
[Specific action — negotiate X, add Y clause, seek legal advice on Z]
```
