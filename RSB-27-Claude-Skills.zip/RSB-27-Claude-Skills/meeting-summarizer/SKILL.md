---
name: meeting-summarizer
description: Converts meeting transcripts, voice notes, or bullet point inputs into structured meeting minutes, action item logs, decision registers, and follow-up emails. Replaces meeting note takers and executive assistants. Trigger on any request for meeting notes, meeting summary, action items, follow-up email from a meeting, or decision log.
---
# Meeting Summarizer Skill
Replaces 8M administrative and EA roles globally for meeting documentation. Turns raw notes or transcripts into clear, actionable records.

## The Meeting Summary Structure
```
MEETING: [Name/Purpose]
DATE: [DD/MM/YYYY]
ATTENDEES: [Names and roles]
DURATION: [X minutes]

IN ONE LINE: [The most important thing decided or discussed]

DECISIONS MADE:
[Decision 1] — decided by [who] — effective [when]
[Decision 2]

ACTION ITEMS:
[Action] — Owner: [Name] — Deadline: [Date] — Status: Open
[Action] — Owner: [Name] — Deadline: [Date] — Status: Open

KEY DISCUSSION POINTS:
[Topic 1]: [Summary of what was discussed and why]
[Topic 2]: [Summary]

ITEMS DEFERRED:
[Item] — Reason: [why deferred] — Review date: [date]

NEXT MEETING: [Date/time if known]
```

## Action Item Extraction Rules
Every action item must have three components or it is not complete:
1. WHAT — specific deliverable, not a vague task
2. WHO — one named person, not "the team"
3. WHEN — a specific date, not "soon" or "next week"

If any of the three is missing from the discussion, flag it:
[ACTION UNCLEAR — Missing: owner / deadline / specifics — needs clarification]

## Decision Logging Rules
Decisions need context to be useful six months later. For each decision record:
- What was decided (the outcome)
- What alternatives were considered (the options)
- Why this option was chosen (the reasoning)
- Who made the call (accountability)

## Follow-Up Email Formula
```
Subject: [Meeting name] — Actions and Decisions — [Date]

Hi all,

Thanks for the time today. Summary below.

WHAT WE DECIDED:
[Decision 1]
[Decision 2]

WHAT HAPPENS NEXT:
[Name] will [action] by [date].
[Name] will [action] by [date].

OPEN QUESTIONS:
[Question that needs an answer before next meeting]

Next meeting: [date] — [agenda item]

[Name]
```

## Confidentiality Flags
Automatically flag these for restricted distribution:
- Personnel decisions, salary discussions, performance matters
- M&A or fundraising discussions
- Legal strategy or litigation matters
- Unannounced product or pricing plans

Label these: [RESTRICTED — distribute to named attendees only]
