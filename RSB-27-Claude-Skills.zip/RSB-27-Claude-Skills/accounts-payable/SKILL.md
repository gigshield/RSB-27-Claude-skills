---
name: accounts-payable-handler
description: Processes invoice queries, vendor payment disputes, payment acknowledgements, reconciliation summaries, and accounts payable correspondence. Replaces AP clerks and finance administrators. Trigger on any request involving invoice processing, vendor payment, payment dispute, AP query, reconciliation, or finance correspondence.
---
# Accounts Payable Handler Skill
Replaces 10M AP clerks and finance administrators globally. Handles invoice correspondence, payment queries, and reconciliation at senior AP level.

## Invoice Processing Checklist
Before approving any invoice, verify:
```
[  ] Vendor name matches approved vendor list
[  ] Invoice number is unique (not a duplicate)
[  ] Invoice date is within acceptable submission window (usually 90 days)
[  ] Amount matches purchase order or contract
[  ] Tax calculation is correct (GST rate applied correctly for India)
[  ] Goods or services have been received/confirmed
[  ] Authorised approver has signed or approved
[  ] Bank details match on file (flag if different — fraud risk)
```

## Vendor Query Response Formula
```
PAYMENT STATUS QUERY:
Hi [Vendor name],

Invoice [number] for Rs [amount] dated [date] is [STATUS]:

Approved and processing: Expected payment date is [date] via [NEFT/RTGS/Cheque].
Under review: We are verifying [specific item]. Expected resolution by [date].
On hold: We need [specific document/approval] before processing. Please provide by [date].
Paid: Transaction reference [number] on [date]. Please check your account.

For further queries, contact [name] at [email].

[Name]
AP Team
```

## Payment Dispute Resolution Formula
```
When a vendor claims non-payment but our records show payment:

Hi [Name],

We show payment of Rs [amount] against invoice [number] on [date].
Transaction reference: [UTR/reference number].
Bank: [our bank name], Account [last 4 digits].

If this has not reached you:
Please provide your bank's confirmation that the funds were not received.
We will then initiate a bank trace.

Typical trace resolution: 3 to 5 business days.

[Name]
```

## GST Reconciliation Rules (India-specific)
```
INPUT TAX CREDIT can only be claimed if:
- Supplier has filed their GSTR-1
- Invoice appears in your GSTR-2A
- Invoice is within the claim window
- Goods/services are for business use

Flag invoices where GST rate does not match:
- 0% (exempt), 5%, 12%, 18%, 28% — only valid rates
- Composition scheme vendors cannot charge GST to B2B buyers
- RCM applies when purchasing from unregistered vendors above threshold
```

## Month-End Reconciliation Summary Format
```
AP RECONCILIATION — [Month Year]

Opening AP balance: Rs [X]
Invoices received: Rs [X] ([N] invoices)
Payments made: Rs [X] ([N] payments)
Credit notes: Rs [X]
Closing AP balance: Rs [X]

Aged AP:
Current (0-30 days): Rs [X] — [N] invoices
31-60 days: Rs [X] — [N] invoices
61-90 days: Rs [X] — [N] invoices
Over 90 days: Rs [X] — [N] invoices — [FLAG: escalate these]

Disputed invoices on hold: Rs [X] — reason: [summary]
```
