---
name: social-media-manager
description: Creates platform-native social media content, posting strategies, caption libraries, hashtag strategies, and content calendars across Instagram, LinkedIn, Twitter/X, and YouTube. Replaces social media management teams. Trigger on any request for social media content, caption, posting strategy, hashtag research, content calendar, or platform strategy.
---
# Social Media Manager Skill
Replaces 5M social media managers globally. Creates platform-native content that the algorithm rewards and audiences actually engage with.

## Platform Rules — Non-Negotiable

### Instagram
- Caption hook must be first 125 characters (before "more" cutoff)
- Reels: hook in first 1.5 seconds, 3 points, 60 seconds maximum
- Hashtags: 3 to 5 only, placed at end of caption
- Best days: Tuesday, Wednesday, Saturday

### LinkedIn
- First line determines if they click "see more" — make it count
- No hashtags in the first 4 lines
- 4 posts per week maximum before quality degrades
- Comments matter more than likes for reach

### Twitter/X
- First tweet of a thread does all the work — front-load the best point
- Threads: 5 to 8 tweets maximum
- Reply to large accounts before posting your own content
- Hot takes within 2 hours of news breaking

### YouTube
- Title: specific outcome + specific method + specific timeframe
- Thumbnail: face + number + high contrast background
- Description: keyword in first sentence, full timestamps, affiliate links

## Caption Formula
```
LINE 1: Hook — fact, number, or counterintuitive claim. Under 15 words.
LINES 2-4: Stakes — why this matters to the reader specifically.
LINES 5-10: Content — numbered points or a story.
LINE 11: Insight — the meta-point bigger than the content.
LINE 12: CTA — one action only.
```

## Content Ratio (per 10 posts)
- 4 Education posts (build trust, get saves)
- 3 Pain/Opinion posts (attract right audience)
- 2 Proof posts (case studies, results)
- 1 Direct offer or handraiser

## Hashtag Research Process
For any topic, use this priority stack:
1. One mega tag (10M+ posts) — discoverability
2. Two large tags (1M-5M posts) — niche reach
3. Two micro tags (under 100K posts) — engaged community
Rotate every 2 weeks. Track which combinations drive profile visits, not just views.
