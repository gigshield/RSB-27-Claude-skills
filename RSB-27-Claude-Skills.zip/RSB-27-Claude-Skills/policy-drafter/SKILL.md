---
name: policy-drafter
description: Drafts company policies, HR policies, compliance policies, standard operating procedures, codes of conduct, and regulatory documentation. Produces legally-aware, clear, and enforceable policy documents. Trigger on any request for a policy document, HR policy, compliance policy, code of conduct, acceptable use policy, or company rules document.
---
# Policy Drafter Skill
Replaces 2M policy writers and compliance officers globally for first-draft policy creation. Produces clear, enforceable, and legally-aware policy documents.

## Policy Document Structure
```
POLICY TITLE: [Name — should describe the subject, not be vague]
POLICY ID: [Reference number]
VERSION: [X.X]
EFFECTIVE DATE: [Date]
REVIEW DATE: [Date — typically annual]
OWNER: [Role responsible for this policy]
APPROVED BY: [Authorising authority]
APPLIES TO: [Who is covered by this policy]

PURPOSE:
One paragraph. Why this policy exists. What problem it solves or what it protects.

SCOPE:
Who it applies to. What situations it covers. What it explicitly does not cover.

POLICY STATEMENT:
The core rules. Numbered. Plain language. No ambiguity.
Each rule should be independently understandable.

RESPONSIBILITIES:
[Role 1] is responsible for: [specific things]
[Role 2] is responsible for: [specific things]
Employees are responsible for: [what all covered people must do]

PROCEDURE:
Step by step process for complying with or implementing this policy.

BREACH AND CONSEQUENCES:
What constitutes a breach. What the consequences are. Who decides.
Be specific. "May result in disciplinary action" is unenforceable.

DEFINITIONS:
Any term used in this policy that could be interpreted differently.

RELATED DOCUMENTS:
[Links or references to related policies, procedures, or regulations]

REVISION HISTORY:
Version | Date | Change | Approved by
```

## Policy Writing Rules
```
LANGUAGE:
Use "must" for mandatory requirements. Not "should" or "is expected to."
Use "may" for discretionary items.
Use "will" for what the company commits to doing.
Never use "shall" — it is archaic and confusing.

SPECIFICITY:
Wrong: "Employees must maintain confidentiality."
Right: "Employees must not share customer data, financial information, 
or unreleased product information with any person outside the company 
without written approval from their department head."

ENFORCEABILITY:
Every rule must have an owner who can enforce it.
Every rule must define what a breach looks like.
If you cannot define what breaks the rule, the rule is not ready.
```

## Common HR Policy Templates

### Leave Policy Key Clauses
```
Types of leave: [Annual / Sick / Maternity / Paternity / Bereavement / Unpaid]
Entitlement: [Days per year per type]
Accrual: [How days accumulate — from joining date / calendar year start]
Carry-over: [How many days can be carried to next year, if any]
Notice required: [How much advance notice for planned leave]
Approval: [Who approves, timeline, grounds for refusal]
Encashment: [Can unused leave be paid out, under what conditions]
```

### Acceptable Use Policy Key Clauses
```
Covered systems: [Company devices, email, network, cloud tools]
Permitted use: [What is allowed on company systems]
Prohibited use: [What is explicitly not allowed — be specific]
Monitoring: [Company's right to monitor, how, what they do with findings]
Data ownership: [Who owns data created on company systems]
Breach consequences: [Specific outcomes]
```

## Legal Flags
Always note that policy documents affecting employment conditions should be reviewed by qualified employment counsel before implementation, particularly:
- Policies involving employee monitoring
- Policies affecting compensation or benefits
- Policies with disciplinary or termination implications
- Policies in heavily regulated sectors (finance, healthcare, education)
