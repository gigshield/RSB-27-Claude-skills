---
name: sales-outreach-writer
description: Writes cold outreach emails, LinkedIn connection messages, follow-up sequences, and sales DMs that get replies. Replaces SDR and business development teams. Produces research-led, persona-specific outreach that reads like it was written by a senior sales rep who did their homework. Use whenever writing cold emails, LinkedIn outreach, follow-up sequences, sales DMs, or prospecting messages. Trigger on any mention of cold email, outreach, SDR, lead generation, prospecting, follow-up sequence, or sales message.
---

# Sales Outreach Writer Skill

Replaces a team of 150 SDRs and BDRs. Writes outreach that gets replies because it is specific, short, and about the prospect — not about you.

---

## The One Rule That Changes Everything

Bad outreach is about the sender. Good outreach is about the recipient.

Every sentence in a cold email should answer the question: "Why should this specific person care about this specific sentence right now?"

If a sentence does not answer that, cut it.

---

## The 3-Line Cold Email Formula

The best performing cold emails in 2025 are under 75 words. This is the structure:

```
Line 1: Something specific about them that proves you did research (1 sentence)
Line 2: The one problem you help with, stated in their language not yours (1 sentence)
Line 3: One low-friction ask — not a meeting, a question (1 sentence)
Signature: Name, title, one proof point
```

### Example
```
Subject: Your Q3 hiring post

Saw you are scaling the engineering team from 8 to 20 people in Q3.

Most companies at that stage spend the first 6 months fixing culture debt from hiring too fast. We help avoid that.

Quick question: is onboarding standardised yet or still founder-led?

Rishik
Built 3 products with remote teams across India
```

---

## The 5-Touch Follow-Up Sequence

Most replies come after the third contact. Most salespeople stop after the first.

```
DAY 1: The opening email (formula above)

DAY 3: The value add
Do not follow up. Send something useful.
"Saw this report on [their industry] this morning. Page 4 is relevant to what you are building."
One sentence. One link. No ask.

DAY 7: The perspective
Share a specific observation about their business.
"Noticed your pricing page changed last week. Moving upmarket or testing something?"
Two sentences. One question.

DAY 14: The honest bump
"Still interested in this. If timing is off, say so and I will come back in a better quarter."
Two sentences. Takes the pressure off.

DAY 21: The breakup
"Closing your file. If the [problem] ever becomes a priority, reply to this thread."
Two sentences. This gets the most replies because it removes all pressure.
```

---

## Persona Frameworks

Write differently for each decision-maker type.

### The CTO
What they care about: Speed, quality, technical debt, team capacity
What they fear: Building the wrong thing, shipping slow
Opening line structure: Reference their tech stack, a recent GitHub commit, or a specific product decision
Ask: A technical question, not a meeting request

### The CEO / Founder
What they care about: Revenue, retention, burn rate
What they fear: Running out of runway, hiring the wrong people
Opening line structure: Reference their fundraising, a press mention, or their growth trajectory
Ask: A revenue or growth question

### The Head of Marketing
What they care about: Leads, brand, content performance
What they fear: Wasted budget, bad agency partners
Opening line structure: Reference their content, a campaign you noticed, or their positioning
Ask: A question about their current biggest channel challenge

### The HR / People Leader
What they care about: Retention, culture, hiring speed
What they fear: Bad hires, high churn, culture damage at scale
Opening line structure: Reference their open roles or their Glassdoor reviews
Ask: A question about where they are losing candidates in the funnel

---

## Subject Line Formulas

The subject line determines whether the email gets opened. Keep it under 40 characters.

```
[Their company name] + [something specific]
"Razorpay + onboarding gap I noticed"

[A number] + [relevant to their role]
"3 things your Q3 hiring post told me"

[Reference to recent event]
"Re: your funding announcement"

[Genuine question]
"Is your sales cycle actually 6 weeks?"

[Name drop]
"Spoke with [mutual connection] — they mentioned you"
```

Never: "Following up on my previous email" as a subject line
Never: Your company name in the subject line of a cold email

---

## LinkedIn DM Formula

LinkedIn DMs have a 300-character preview. The entire hook must fit in 300 characters.

```
[Observation about their recent post or activity] + [one relevant question]

"Your post about the SDR pipeline got me thinking — are you testing
any outbound channels beyond LinkedIn right now?"
```

No pitch in the first DM. Ever. The first DM earns a conversation. The second DM earns the pitch.

---

## What Never to Write

```
BANNED OPENERS:
"Hope this email finds you well"
"I came across your profile and was impressed"
"I would love to connect"
"Quick question" (as the subject line — everyone uses this now)
"I know you're busy"
"I'll keep this brief" (then do not keep it brief)
"We help companies like yours"

BANNED CLOSERS:
"Please let me know if you'd be interested"
"Looking forward to hearing from you"
"Would love to get 15 minutes on your calendar"
"Feel free to reach out"
```

Replace every one of these with a specific observation or a direct question.
