---
name: bid-proposal-writer
description: Writes RFP responses, tender documents, government bid submissions, and business proposals that win contracts. Covers executive summaries, technical approaches, pricing narratives, and compliance matrices. Trigger on any request for an RFP response, tender document, bid submission, government proposal, or contract proposal.
---
# Bid Proposal Writer Skill
Replaces 1.5M bid writers globally. Produces winning proposals that answer the actual question behind the RFP, not just the stated requirements.

## The First Rule of Bid Writing
Evaluators read dozens of proposals. They are tired. They are looking for reasons to eliminate, not reasons to select.

Your proposal must:
1. Be easy to evaluate — match their structure exactly
2. Answer what they actually care about — not what they asked literally
3. Prove you have done this before — specifically, with numbers
4. Make the risk of choosing you feel smaller than the risk of not choosing you

## Proposal Structure
```
COVER PAGE: Company name, bid reference, date, contact. Nothing else.

EXECUTIVE SUMMARY (1 to 2 pages — most important section):
- What you are proposing in one sentence
- Why you are the right choice in three specific reasons
- The single most compelling proof point you have
- What happens if they select you in the next 30 days

UNDERSTANDING OF REQUIREMENT:
Restate their need in your own words. This proves you read it.
Identify the unstated need behind the stated need.
"You are not just looking for X, you are solving the underlying problem of Y."

TECHNICAL APPROACH:
How you will do it. Step by step. With timelines.
The methodology that makes you different.
Risk mitigation: what could go wrong and how you prevent it.

TEAM AND CREDENTIALS:
Named individuals, not "our team"
Relevant experience: same industry, same problem, same scale
Reference projects: client name, scope, outcome, contact if permitted

PRICING:
Transparent. Itemised. Justified.
Show what is included and what is not.
Show the ROI of choosing you over alternatives.

COMPLIANCE MATRIX:
Table with their requirements in column 1.
Your compliance (yes/partial/no with explanation) in column 2.
Where in your proposal they can find the evidence in column 3.

ANNEXURES:
CVs, certifications, financial statements, references as required.
```

## Executive Summary Formula
```
[Organisation name] is seeking [their stated need].
The underlying challenge is [the real problem behind the RFP].

[Your company] proposes [your solution in one sentence].

We have delivered [comparable project] for [similar client],
achieving [specific outcome]. We are the only bidder who [differentiator].

Our approach ensures [their top fear] does not happen by [specific mechanism].

Investment: Rs [X]. Timeline: [X] weeks. Start date available: [date].
```

## Common Bid-Losing Mistakes
- Writing about your company instead of their problem
- Generic methodology that could apply to anyone
- No named personnel — "our experienced team" is not credible
- Missing compliance items without noting the exception
- Pricing that is not justified — cheapest is not always selected
- Submission after deadline — automatic disqualification in government bids
