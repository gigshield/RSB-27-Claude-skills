---
name: email-copywriter
description: Writes promotional emails, product launch emails, re-engagement campaigns, abandoned cart sequences, and sales emails that convert. Covers subject lines, preview text, email body, and CTA strategy. Trigger on any request for a promotional email, sales email, marketing email, email campaign, or email copy.
---
# Email Copywriter Skill
Replaces 2M email marketing specialists globally. Writes emails people open, read, and click.

## The Email Anatomy
```
SUBJECT LINE: 40 to 50 characters. Creates open.
PREVIEW TEXT: Extends subject line curiosity. Never repeats it.
OPENING LINE: First visible line after greeting. Hooks or loses the reader.
BODY: One idea. One benefit. One story. Never three of each.
CTA: One button. One action. Maximum three words on the button.
```

## Subject Line Formulas by Email Type
```
PROMOTIONAL: "Rs [X] off. [Time limit]. No code needed."
LAUNCH: "It is finally here. [Product name]."
RE-ENGAGEMENT: "We have not heard from you. Here is why that matters."
CART ABANDONMENT: "You left [product] behind."
NEWSLETTER: "[The most interesting thing from this week]"
```

## Email Body Rules
- Under 200 words for promotional emails
- One product. One benefit. Do not list features.
- Write for the person who skims. Every paragraph must work standalone.
- Use short sentences. Long sentences bury the point.
- Never use "Click here" as link text. Name the destination.

## CTA Button Copy
```
WEAK: "Click here" / "Learn more" / "Submit"
STRONG: "Get my free audit" / "Claim your seat" / "Start today"
Rule: Button text = what happens after clicking, not the action of clicking
```

## Re-engagement Email Formula
```
Subject: [Their name], are you still there?
Preview: No pressure. Just checking.

Body:
It has been [X] days since you last [opened / purchased / logged in].

We have added [specific thing] since then.

If this is not useful to you anymore, unsubscribe below.
No hard feelings. We would rather you only hear from us when it matters.

If you want to stay, [one action].

[Name]

[Unsubscribe] — this link being prominent INCREASES trust and retention
```

## Deliverability Rules
- Never send to a list that has not been emailed in 90 days without a re-permission campaign first
- Clean bounces immediately after every send
- Unsubscribe must be one click — anything more is illegal in most jurisdictions
- Send from a named person's email, not info@ or noreply@
