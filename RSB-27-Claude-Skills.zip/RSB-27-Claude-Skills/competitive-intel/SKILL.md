---
name: competitive-intelligence-reporter
description: Produces structured competitor monitoring reports, battlecards, win/loss analysis, pricing intelligence summaries, and competitive positioning documents. Replaces competitive intelligence analysts. Trigger on any request for competitor analysis, competitive report, battlecard, win/loss analysis, competitive positioning, or market intelligence.
---
# Competitive Intelligence Reporter Skill
Replaces 500K competitive intelligence analysts globally. Produces decision-ready competitor intelligence.

## Weekly Competitor Monitoring Report
```
COMPETITIVE INTELLIGENCE BRIEF — [Week of DATE]
PREPARED FOR: [Sales / Product / Leadership]
COMPETITORS MONITORED: [List]

TOP STORY:
[The single most significant competitive development this week and why it matters]

COMPETITOR UPDATES:

[Competitor Name]
What changed: [Specific — product launch, pricing change, leadership change, partnership]
Source: [Where this was observed]
Impact on us: [How this affects our sales, product, or positioning]
Recommended response: [Specific action]

[Repeat for each competitor]

DEALS INTELLIGENCE:
Won against [competitor]: [What we won on — price / feature / service]
Lost to [competitor]: [What we lost on — price / feature / service]
Pattern emerging: [If 3 or more data points suggest a trend]

NEXT WEEK TO WATCH:
[Anticipated competitor move based on signals — launch, earnings call, event]
```

## Battlecard Structure
```
COMPETITOR: [Name]
BATTLECARD FOR: [Sales team]
LAST UPDATED: [Date]

ONE-LINE SUMMARY:
"[Competitor] is strong at [X] and weak at [Y]. We win when [Z]."

THEIR STRENGTHS (be honest — sales needs accurate intel):
[Strength 1]: Evidence: [customer review, case study, or data point]
[Strength 2]: Evidence: [source]

OUR ADVANTAGES:
[Advantage 1]: Proof point: [specific evidence]
[Advantage 2]: Proof point: [specific evidence]

THEIR COMMON OBJECTIONS ABOUT US:
They say: "[Common attack]"
We say: "[Specific rebuttal with evidence]"

THEIR WEAKNESSES TO PROBE:
Question to ask customer: "[Question that surfaces their limitation]"
Expected pain point: "[What customers say in reviews about this]"

WHEN WE WIN:
Ideal customer profile where we consistently beat them
Deal size / industry / use case where we have strongest win rate

WHEN WE LOSE:
Be honest. Sales teams know anyway. If you lie, they stop using the battlecard.
"We typically lose when: [honest situation]"

PRICING INTELLIGENCE:
Their pricing model: [what is known / estimated]
Our positioning: [how we explain our pricing vs theirs]
```

## Win/Loss Analysis Format
```
DEAL: [Reference — no client name if confidential]
OUTCOME: [Won / Lost]
COMPETITORS: [Names]
DEAL SIZE: Rs [X]

DECISION FACTORS (ranked by buyer):
1. [Factor] — How we scored vs competitor: [Better / Equal / Worse]
2. [Factor] — Score: [Better / Equal / Worse]
3. [Factor] — Score: [Better / Equal / Worse]

PRIMARY WIN/LOSS REASON (one sentence):
Won because: [The single deciding factor]
Lost because: [The single deciding factor]

WHAT WE COULD HAVE DONE DIFFERENTLY:
[Honest assessment of our process, not just the product]

PATTERN (if this is the 3rd similar deal):
"Three losses to [competitor] have been on [X]. This is now a pattern requiring response."
```
