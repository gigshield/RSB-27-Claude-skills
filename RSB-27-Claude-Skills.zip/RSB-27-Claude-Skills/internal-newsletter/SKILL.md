---
name: internal-newsletter-writer
description: Writes employee newsletters, all-hands communication digests, HR updates, company culture content, and internal weekly briefings. Replaces internal communications managers and HR communications teams. Trigger on any request for an internal newsletter, employee communication, all-hands digest, internal announcement roundup, or company update email.
---
# Internal Newsletter Writer Skill
Replaces 1M internal communications professionals globally. Writes employee newsletters people actually read.

## Why Internal Newsletters Fail
Most internal newsletters are read by 20 to 30 percent of employees.
The best ones hit 60 to 70 percent.

The gap: bad newsletters are written for the company. Good newsletters are written for the employee.

Every line should answer: why does this matter to the person reading it?

## Internal Newsletter Structure
```
SUBJECT LINE: [One thing that is genuinely interesting to this employee — not a company name + issue number]

OPENING — THE HONEST LEDE (50 words)
The most interesting thing happening at the company right now.
Not the most positive. The most interesting.
Employees can smell spin. Honest beats polished every time.

SECTION 1 — WHAT IS HAPPENING (200 words)
2 to 3 company updates. For each one:
What is changing, who it affects, when it takes effect.
If it is good news, say so without overselling.
If it is neutral news, state it plainly.
If it is hard news, name it — do not make people decode the subtext.

SECTION 2 — WHAT PEOPLE ARE BUILDING (150 words)
One team or project spotlight. Real work, real person.
Quote from someone doing the work, not a manager about the work.
One photo if possible.

SECTION 3 — WHAT YOU NEED TO KNOW (100 words)
3 to 5 quick items. Deadlines, policy changes, events.
Format: [Item] — [What to do] — [By when] — [Who to contact]

SECTION 4 — FROM LEADERSHIP (100 words — optional)
Only include if leadership has something genuinely useful to say.
If it is a generic "we are committed to our values" paragraph, cut it.
Leaders who write honestly about something hard build more trust than those who celebrate everything.

CLOSING — ONE QUESTION (20 words)
A genuine question for employees. Reply opens a conversation.
"What is one thing that would make your work easier next month?"
```

## Headlines That Get Opened
```
Wrong: "Company Newsletter — Issue 42"
Right: "The one thing changing for everyone in March"

Wrong: "HR Update — Quarter 1 2026"
Right: "Leave policy update — what is different and what is not"

Wrong: "All-Hands Recap"
Right: "What was actually decided at Monday's all-hands"
```

## Sensitive Communication Rules
```
REDUNDANCY / LAYOFFS:
Never be announced in a newsletter. This requires a separate, direct communication.
Newsletter can acknowledge the aftermath: "Following last week's announcement..."

LEADERSHIP CHANGES:
Announce departure and appointment together.
Be specific about timeline and transition.
Departing leader writes their own goodbye — do not write it for them.

POLICY CHANGES:
State what changes and what does not.
Give a date. Employees hate ambiguity on rules.
Provide one contact for questions — a real person, not HR@.

PERFORMANCE / BUSINESS RESULTS:
Be specific. "Strong quarter" means nothing.
"Revenue up 18% year on year — here is what drove it" is readable.
Employees who understand the business perform better.
```

## Tone Calibration
```
All-company announcement: Clear, calm, informative.
Culture / recognition: Warm but not sycophantic.
Hard news: Direct, honest, no corporate euphemism.
Operational update: Efficient. Employees are busy.
Leadership voice: Personal, not PR-polished.
```

## The One Metric That Matters
Track reply rate, not open rate.
A newsletter with 40% opens and 0.5% replies is not connecting.
A newsletter with 30% opens and 5% replies is building community.
