---
name: seo-content-optimizer
description: Conducts keyword research, writes SEO-optimised meta titles and descriptions, audits existing content for on-page SEO, creates content briefs, and produces structured schema recommendations. Replaces SEO analyst teams. Trigger on any request for keyword research, meta description, SEO audit, content brief, on-page SEO, or search ranking improvement.
---
# SEO Content Optimizer Skill
Replaces 1M SEO analysts globally. Handles keyword research, on-page optimisation, meta copy, and content briefs at the level of a senior SEO strategist.

## Keyword Research Framework
```
STEP 1: SEED KEYWORD — the core topic in 1 to 3 words
STEP 2: INTENT CLASSIFICATION
  Informational: "how to" / "what is" / "why" — user wants to learn
  Navigational: brand name searches — user wants a specific site
  Commercial: "best" / "top" / "review" — user is comparing options
  Transactional: "buy" / "price" / "near me" — user wants to act
STEP 3: CLUSTER — group related keywords by intent
STEP 4: PRIORITISE — high volume + low competition + high commercial value
```

## On-Page Optimisation Checklist
```
TITLE TAG: Primary keyword in first 60 characters. Unique per page.
META DESCRIPTION: 150-160 characters. Keyword present. Ends with a benefit.
H1: One per page. Contains the primary keyword naturally.
H2s: Target secondary keywords. Questions where possible.
BODY: Primary keyword in first 100 words. Once per 150 words maximum.
IMAGES: Alt text describes what is in the image. Includes keyword where natural.
URL: Short. Hyphen-separated words. Primary keyword present. No dates.
INTERNAL LINKS: At least 2 internal links per article. Anchor text is descriptive.
```

## Meta Title Formulas
```
Commercial: [Primary Keyword] — [Differentiator] | [Brand]
"Best AI Tools for Indian Startups — 2026 Comparison | RSB"

Informational: [Question] — [Benefit of Reading]
"How to Automate Your Business With AI — Step by Step Guide"

Transactional: [Action] [Keyword] [Location/Qualifier]
"Buy AI Consulting Services India — Fixed Price, Fast Delivery"
```

## Content Brief Structure
```
TARGET KEYWORD: [primary]
SECONDARY KEYWORDS: [list 3 to 5]
SEARCH INTENT: [informational / commercial / transactional]
WORD COUNT TARGET: [based on top 3 ranking pages average]
ANGLE: [what makes this different from what ranks]

OUTLINE:
H1: [title]
H2: [section 1 — covers X secondary keyword]
H2: [section 2]
H3 under section 2: [subsection]
H2: [FAQ — covers People Also Ask questions]

MUST INCLUDE: [specific data point or claim to validate]
INTERNAL LINKS TO: [2 to 3 existing pages]
CTA: [what the reader does after reading]
```

## Common SEO Mistakes to Flag
- Keyword stuffing — reads as spam to Google and humans
- Thin content under 600 words for informational queries
- Duplicate meta descriptions across pages
- Missing alt text on all images
- No internal linking strategy
- Pages targeting the same keyword (keyword cannibalisation)
