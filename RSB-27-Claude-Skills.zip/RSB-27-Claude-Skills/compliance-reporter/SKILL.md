---
name: compliance-reporter
description: Produces regulatory compliance reports, audit trail summaries, risk registers, compliance gap analyses, and board-level compliance dashboards. Covers GDPR, India PDPB, GST compliance, RBI guidelines, and general corporate governance. Trigger on any request for a compliance report, audit summary, risk register, regulatory filing, compliance dashboard, or governance document.
---
# Compliance Reporter Skill
Replaces 2M compliance officers globally for report generation. Produces structured, audit-ready compliance documentation.

## Compliance Report Structure
```
COMPLIANCE REPORT
Entity: [Company name and registration]
Period: [Reporting period]
Prepared by: [Name, role]
Date: [Date]
Classification: [Confidential]

EXECUTIVE SUMMARY
Overall compliance status: [Green / Amber / Red]
Critical findings: [Number]
High findings: [Number]
Medium findings: [Number]
Low findings: [Number]

SCOPE OF REVIEW
Regulations covered: [List]
Business units reviewed: [List]
Review methodology: [Document review / Interview / Testing / All three]
Limitations: [Any scope restrictions that affect conclusions]
```

## Finding Classification
```
CRITICAL: Breach that has already occurred OR is actively occurring.
Regulatory or legal action is an immediate risk.
Requires CEO and Board notification within 24 hours.

HIGH: Control gap that will produce a breach if not addressed.
Regulatory scrutiny would likely identify this as a finding.
Requires remediation within 30 days.

MEDIUM: Control weakness that increases risk but has not caused a breach.
Requires remediation within 90 days.

LOW: Best practice deviation. No immediate regulatory risk.
Remediate within next compliance cycle.
```

## Finding Report Format
```
FINDING ID: [F001]
CLASSIFICATION: [Critical / High / Medium / Low]
REGULATION: [Specific regulation and clause]
FINDING: [What the gap or breach is — one paragraph, specific]
EVIDENCE: [What was reviewed to reach this conclusion]
RISK: [What happens if this is not remediated]
RECOMMENDATION: [Specific action to remediate]
OWNER: [Who is responsible for remediation]
DEADLINE: [Date by which remediation must be complete]
STATUS: [Open / In progress / Closed]
```

## India-Specific Compliance Areas

### GST Compliance Checklist
```
Monthly:
[ ] GSTR-1 filed by 11th of following month
[ ] GSTR-3B filed by 20th of following month
[ ] Input tax credit reconciled against GSTR-2A
[ ] E-invoicing compliance for applicable turnovers

Quarterly:
[ ] GSTR-1 quarterly filers deadline met
[ ] ITC reversal calculated and filed

Annual:
[ ] GSTR-9 annual return filed
[ ] GSTR-9C reconciliation statement if applicable
[ ] GST audit completed where turnover exceeds threshold
```

### RBI Compliance for Fintechs
```
[ ] Lending licence or partner bank agreement current
[ ] KYC procedures meet current RBI guidelines
[ ] Interest rate disclosure meets Fair Practice Code
[ ] Grievance redressal mechanism active and documented
[ ] Data localisation requirements met for payment data
[ ] Annual return filed with RBI if applicable
```

## Risk Register Format
```
RISK ID | RISK DESCRIPTION | LIKELIHOOD | IMPACT | RATING | OWNER | MITIGATION | REVIEW DATE
R001 | [Risk] | H/M/L | H/M/L | [H/M/L] | [Name] | [Action] | [Date]
```

Rating = Likelihood × Impact:
H × H = Critical, H × M or M × H = High, M × M = Medium, L × any = Low
