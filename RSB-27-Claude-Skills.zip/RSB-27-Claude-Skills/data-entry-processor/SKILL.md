---
name: data-entry-processor
description: Processes, structures, validates, and formats data from unstructured inputs including forms, emails, documents, and raw text into clean database-ready formats. Replaces data entry teams. Trigger on any request to process data, clean a dataset, extract information from a document, format records, or convert unstructured text to structured data.
---
# Data Entry Processor Skill
Replaces 15M data entry operators globally. Extracts, validates, and structures data at accuracy levels that exceed manual entry.

## The Processing Framework
```
Step 1: IDENTIFY the data type (financial, contact, inventory, HR, compliance)
Step 2: EXTRACT all relevant fields from the input
Step 3: VALIDATE against expected format and flag anomalies
Step 4: STRUCTURE into the target format
Step 5: FLAG missing or inconsistent data for human review
```

## Standard Field Extraction
For any document, extract these categories if present:
```
ENTITY DATA: Names, companies, IDs, registration numbers
DATE DATA: All dates normalised to DD/MM/YYYY for India, YYYY-MM-DD for databases
FINANCIAL DATA: Amounts with currency, tax rates, totals verified against line items
CONTACT DATA: Email, phone (with country code), address (structured by field)
STATUS DATA: Any field indicating state, condition, or stage
```

## Validation Rules
- Numbers: Total must equal sum of line items. Flag if not.
- Dates: Must be logical sequence. End date after start date. Flag reversals.
- Emails: Must match format x@x.x. Flag malformed addresses.
- Phone: Indian numbers are 10 digits after +91. Flag anything else.
- Mandatory fields: List which fields cannot be empty. Flag all blanks.

## Output Formats
```
CSV: Field1,Field2,Field3 with header row always included
JSON: {"field": "value"} with consistent key naming
TABLE: Markdown table with aligned columns
FORM FILL: Field label: Value format, one per line
```

## Error Handling
```
MISSING DATA: [MISSING - field name] — never leave blank silently
AMBIGUOUS DATA: [UNCLEAR: "original text" — possible values: X or Y]
CONFLICTING DATA: [CONFLICT: Field A says X but Field B says Y]
OUT OF RANGE: [CHECK: Value X is outside expected range of Y to Z]
```
