---
name: executive-communicator
description: Writes board papers, CEO updates, investor briefings, executive summaries, company-wide announcements, and leadership communications. Replaces executive communications specialists and chief of staff writing functions. Trigger on any request for a board paper, CEO communication, executive summary, leadership announcement, or c-suite writing.
---
# Executive Communicator Skill
Replaces 500K executive communications professionals globally. Writes board-level and CEO communications that are clear, decisive, and reflect senior authority.

## The Executive Communication Principle
Executives communicate to move. Every word should move someone toward a decision, an action, or a changed position.

Remove everything that does not move.

## Board Paper Formula
```
PAPER TITLE: [Decision or topic — be specific]
PRESENTED BY: [Name, Title]
DATE: [Board meeting date]
CLASSIFICATION: [Confidential / Restricted / Open]

RECOMMENDATION (first, always):
The board is asked to [approve / note / decide]:
[Specific resolution in one sentence]

EXECUTIVE SUMMARY (150 words maximum):
Why this is before the board now.
What the options are.
What is being recommended and why.
What the key risk is if the recommendation is not adopted.

BACKGROUND (200 to 400 words):
Context that is necessary to evaluate the recommendation.
Nothing else.

OPTIONS CONSIDERED:
Option A: [Description] — Pros: [X] — Cons: [Y]
Option B: [Description] — Pros: [X] — Cons: [Y]
Recommended: [Option X] because [one clear reason]

FINANCIAL IMPLICATIONS:
Cost: Rs [X] | Budget available: Rs [X] | Approval level: [required]

RISKS:
[Risk] — Likelihood: [H/M/L] — Impact: [H/M/L] — Mitigation: [action]

TIMELINE:
[Key milestones if approved]

APPENDICES: [Reference only, not in main paper]
```

## CEO Update Formula (internal)
```
Subject: [Month] Update — What Happened, What Comes Next

[What happened this month — specific, honest, under 100 words]

[What we learned — the insight from what happened]

[What changes because of it — concrete next step with owner and date]

[What I am focused on next month — the CEO's personal priority]

[One question I want the team thinking about]

[Name]
```

## Executive Announcement Principles
```
GOOD NEWS ANNOUNCEMENTS:
Lead with the news. Do not build up to it.
One paragraph on what it means for the audience.
No self-congratulation. Let the news speak.

BAD NEWS ANNOUNCEMENTS:
State the news in the first sentence.
Explain why. Honest, not defensive.
State what changes and for whom.
State what does not change.
Name who is available for questions.

LEADERSHIP CHANGES:
Announce departures and appointments together when possible.
For departures: specific, warm, no overpromising about "exciting next chapters"
For appointments: what they will focus on, not just their title and credentials
```

## What Strips Executive Authority From Writing
- Passive voice in the opening line ("It has been decided that...")
- Hedging language ("It might be worth considering...")
- Lists of 8 things when 3 will do
- Explaining decisions already made as if they are still open
- Thanking people excessively before getting to the point
- "As you know" — if they know, do not say it; if they do not, just say it
