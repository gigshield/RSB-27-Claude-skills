---
name: technical-writer
description: Writes SOPs, user guides, API documentation, technical specifications, process documents, and troubleshooting guides. Converts technical knowledge into clear documentation that non-experts can follow. Trigger on any request for a user guide, SOP, API documentation, technical specification, process document, or troubleshooting guide.
---
# Technical Writer Skill
Replaces 500K technical writers globally. Converts complex technical knowledge into documentation that people actually use.

## The First Rule of Technical Writing
Documentation fails when it is written for the person who already knows.
Write for the person who has never done this before and is doing it alone.

## SOP Formula
```
SOP TITLE: [Name of the process]
SOP ID: [Reference number]
VERSION: [X.X] | EFFECTIVE DATE: [Date] | REVIEW DATE: [Date]
OWNER: [Name/Role] | APPROVED BY: [Name/Role]

PURPOSE:
One sentence. What this SOP enables someone to do.

SCOPE:
Who does this apply to. When it applies. When it does not apply.

BEFORE YOU START — REQUIREMENTS:
Access needed: [Systems, permissions]
Materials needed: [Files, forms, physical items]
Time required: [Approximate time to complete]
Prerequisites: [Other processes that must be completed first]

STEP-BY-STEP PROCEDURE:
Step 1: [Action — verb first, noun second]
  What you should see: [Expected result]
  If this does not happen: [Troubleshooting action]

Step 2: [Action]
  What you should see: [Expected result]
  If this does not happen: [Troubleshooting action]

[Continue for all steps]

COMMON ERRORS AND FIXES:
Error: [What goes wrong] — Fix: [What to do]

CONTACTS FOR HELP:
[Name], [role] — [email/phone] — available [hours]
```

## User Guide Structure
```
GETTING STARTED (first 10 percent of the guide)
Install / setup in under 5 minutes
The one thing the user needs to do first before anything else works
Success indicator: how they know setup worked

CORE TASKS (60 percent of the guide)
The 3 to 5 things 80 percent of users will do 80 percent of the time
One task per section. Task title is a verb phrase. "How to [do X]."

ADVANCED FEATURES (20 percent)
Optional. For power users only.
Mark clearly: "This section is for [specific use case] only."

TROUBLESHOOTING (10 percent)
Problem-based structure. "When [X] happens, do [Y]."
Every error message should appear here with a solution.
```

## API Documentation Template
```
ENDPOINT: [METHOD] /path/to/endpoint
DESCRIPTION: [One sentence on what this endpoint does]

REQUEST:
Headers: [Required headers]
Parameters:
  name: [type] — [required/optional] — [description]
Body: [JSON schema if applicable]

RESPONSE:
Success (200): [Schema] — [Example]
Error codes:
  400: [What causes this and how to fix it]
  401: [Authentication error]
  404: [Resource not found]
  500: [Server error — what to do]

EXAMPLE REQUEST:
[Code block — curl or language-specific]

EXAMPLE RESPONSE:
[Code block]

RATE LIMITS: [Requests per minute/hour]
NOTES: [Any edge cases or important behaviours]
```

## Clarity Rules
- Each instruction = one action. Never "Click X and then Y" in one step.
- Use active imperative. "Click Save" not "The Save button should be clicked."
- Numbers for sequential steps. Bullets for non-sequential items.
- Screenshot for every step that involves a UI. Circle the relevant element.
- Define every acronym on first use. Do not assume prior knowledge.
