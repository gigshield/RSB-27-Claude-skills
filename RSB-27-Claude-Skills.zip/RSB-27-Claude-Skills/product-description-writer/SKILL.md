---
name: product-description-writer
description: Writes ecommerce product listings, catalog descriptions, Amazon/Flipkart product pages, feature benefit copy, and product launch announcements. Replaces product copywriting teams. Trigger on any request for a product description, ecommerce listing, product copy, catalog entry, or product launch announcement.
---
# Product Description Writer Skill
Replaces 3M ecommerce and product copywriters globally. Writes product descriptions that rank, read clearly, and convert browsers into buyers.

## The Product Description Hierarchy
```
LEVEL 1 — The Hook (headline or first sentence):
The single most compelling thing about this product for this buyer.
Not a feature. A feeling or an outcome.

LEVEL 2 — The Promise (2 to 3 sentences):
What their life or work looks like after buying this.
Specific. Sensory. Real.

LEVEL 3 — The Proof (bullet points):
The features that deliver the promise.
Feature + benefit format: "[Feature] so you can [outcome]"

LEVEL 4 — The Specifics (technical details):
Dimensions, materials, compatibility, certifications.
For the buyer who needs to verify before purchasing.

LEVEL 5 — The Remove Doubt (FAQs or guarantee):
Answer the top 3 objections before they are raised.
```

## Feature-Benefit Copy Formula
```
WEAK: "Stainless steel construction."
STRONG: "Stainless steel construction — survives daily drops, dishwasher-safe, 
lasts longer than plastic alternatives."

WEAK: "Fast charging technology."
STRONG: "Fast charging — from 0 to 80% in 35 minutes so you stop waiting 
and start working."

WEAK: "AI-powered."
STRONG: "AI-powered — learns your usage pattern in the first week and 
adapts so you spend less time on settings and more time on work."
```

## Platform-Specific Formatting

### Amazon / Flipkart
```
Title: [Brand] [Product Name] [Size/Variant] [Key Feature] — [Benefit] [Pack size]
Max 200 characters. Include top search keyword near the start.

Bullet points (5 maximum):
Start each with a BOLD BENEFIT then explain in plain text.
FAST CHARGING — 65W GaN charger delivers full charge in 45 minutes, 
not 2 hours.

Product description (500 to 2000 words):
Tell the story of the product. Who it is for. When they will use it.
Why it is better than alternatives. Proof.

Backend keywords:
Not visible. Include all alternate search terms, misspellings, 
related categories. No keyword stuffing in visible copy.
```

### Direct-to-Consumer Website
```
SHORT DESCRIPTION (product list page): 50 to 80 words.
Outcome first. Then three features. Then the single differentiator.

FULL DESCRIPTION (product detail page): 200 to 500 words.
Follow the 5-level hierarchy above.
Include at least one specific use case.
End with social proof quote if available.
```

## What Kills Product Copy
- "Premium quality" — meaningless without a specific proof
- "Best in class" — a claim that requires evidence
- "Revolutionary" — overused to the point of meaning nothing
- Passive voice in descriptions ("The bag was designed to...")
- Listing features without connecting them to outcomes
- Missing: dimensions, compatibility, what is in the box
