---
name: grant-proposal-writer
description: Writes grant applications, funding proposals, CSR project proposals, government scheme applications, and research funding requests. Covers structure, narrative, budget justification, and impact statements for Indian and international funding bodies. Trigger on any request for a grant proposal, funding application, CSR proposal, government scheme application, or research grant.
---
# Grant Proposal Writer Skill
Replaces 1M grant writers globally. Produces funded proposals by answering what evaluators actually score on, not just what is asked.

## The First Rule of Grant Writing
Evaluators are looking for: will this work, will these people deliver it, and is this worth funding over the others?

Every section must answer one of those three questions. Nothing else earns marks.

## Grant Proposal Structure
```
COVER PAGE
Organisation name, registration number, contact, grant reference.

EXECUTIVE SUMMARY (150 to 300 words — written last)
The problem. Your solution. Why you. The ask. The outcome.
This section is often the only thing read before shortlisting.

PROBLEM STATEMENT
Specific data on the problem. Local if the grant is local.
Who is affected. How many. In what way.
Why existing solutions are inadequate.
Do not define the problem so broadly that your solution cannot solve it.

PROPOSED SOLUTION
What you will do. Step by step. With timelines.
Why your approach works when others have not.
What evidence base supports your methodology.

ORGANISATIONAL CAPABILITY
Your track record. Named projects. Outcomes achieved.
Key personnel with relevant experience.
Partnerships that add credibility.

IMPLEMENTATION PLAN
Gantt chart or milestone table.
Month by month activities.
Who does what. What dependencies exist.
What could delay you and how you will manage it.

BUDGET
Itemised. Every line justified.
Personnel costs at market rates, not aspirational rates.
Indirect costs explained, not just added.
Contingency: 5 to 10 percent for most funders, explained.
Cost per beneficiary calculated and stated.

MONITORING AND EVALUATION
How you will know if it is working.
Specific indicators with baseline and target.
Who collects data. How often. What you do if targets are off-track.

SUSTAINABILITY
What happens after the grant ends.
How the programme or impact continues without this funding.
Specific revenue model or institutional commitment.

BUDGET NARRATIVE
Every line item explained in one sentence.
Justify unusual items. Funders question what they do not understand.
```

## Problem Statement Formula
```
[X number] of [target population] in [geography] experience [problem].
This costs them [specific impact: time / money / health / opportunity].
Current solutions fail because [specific reason].
If nothing changes, [consequence in 3 to 5 years].
```

## Impact Statement Formula
```
By [end of project period], [number] [target beneficiaries] will:
[Outcome 1 — specific, measurable]
[Outcome 2 — specific, measurable]

By [12 months post-project], the sustained impact will include:
[Long-term outcome — less specific, trend-based]

This represents [X]% of [total target population] in [geography].
```

## Indian Funding Bodies — Common Requirements

### BIRAC (Biotech)
Research methodology, IP strategy, commercialisation plan, team credentials from recognised institutions.

### DST / SERB (Science and Technology)
Literature review, innovation over existing work, academic publication plan, equipment justification.

### CSR Proposals (Companies Act 2013)
Alignment with Schedule VII activities, measurable social impact, implementing agency credentials, fund utilisation and reporting plan.

### State Government Schemes
Local beneficiary data, gram panchayat or district administration letter of support, land or space documentation if infrastructure involved.

## What Loses Grants
- Vague problem statements without data
- Solutions not matched to the stated problem
- Budgets that add up to a round number (suggests guessing)
- No monitoring plan — funders need to report on their investment
- Personnel costs that seem too low (suggests under-scoping) or too high (greed signal)
- Sustainability described as "seeking further grants"
