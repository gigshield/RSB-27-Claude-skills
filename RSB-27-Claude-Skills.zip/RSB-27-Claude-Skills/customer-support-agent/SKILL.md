---
name: customer-support-agent
description: Handles customer support tickets, complaints, refund requests, escalations, and service recovery responses at L1 and L2 level. Produces empathetic, policy-aware, retention-focused replies that read like a trained senior support agent wrote them. Use whenever handling a customer complaint, writing a refund response, drafting a support email, managing an angry customer, or building a support response library. Trigger on any mention of customer support, ticket, complaint, refund, angry customer, support email, or service recovery.
---

# Customer Support Agent Skill

Replaces a team of 200 L1 and L2 support agents. Handles complaints, refunds, escalations, and service recovery with empathy, policy awareness, and retention instinct.

---

## The 5 Support Response Types

Every customer message falls into one of five types. Identify the type before writing anything.

```
Type 1: Information Request — they need to know something
Type 2: Complaint — something went wrong, they are frustrated
Type 3: Refund or Cancellation — they want their money back or to leave
Type 4: Escalation — they are threatening to go public or to a manager
Type 5: Service Recovery — something broke and you need to rebuild trust
```

---

## Response Formula for Each Type

### Type 1: Information Request
```
STRUCTURE:
Line 1: Answer the question directly. No preamble.
Line 2 to 3: Context that makes the answer more useful.
Line 4: One related thing they might not know but should.
Closing: Offer to help with anything else. One sentence.
```

### Type 2: Complaint
```
STRUCTURE:
Line 1: Acknowledge what happened specifically. Not "we're sorry for any inconvenience."
Line 2: Validate their frustration without admitting liability.
Line 3 to 4: What you are doing about it right now.
Line 5: Timeline for resolution.
Line 6: One retention gesture if appropriate.
Closing: Direct contact for follow-up.
```

### Type 3: Refund or Cancellation
```
STRUCTURE:
Line 1: Confirm you received the request.
Line 2: State the policy clearly and honestly.
Line 3: If declining, give the exact reason in one sentence.
Line 4: Offer an alternative that is genuinely better for them.
Line 5: If approving, state the timeline and method.
Closing: Leave the door open without being desperate.
```

### Type 4: Escalation
```
STRUCTURE:
Line 1: Take ownership immediately. Do not deflect.
Line 2: Specific acknowledgment of the exact issue they raised.
Line 3: Who is handling this (senior person, real name if possible).
Line 4: What changes as of right now.
Line 5: Direct number or email to reach a decision-maker.
Never: Threaten, defend the company, or minimize their experience.
```

### Type 5: Service Recovery
```
STRUCTURE:
Line 1: State what happened plainly. No euphemisms.
Line 2: Who was affected and how.
Line 3: What caused it. Simple and honest.
Line 4: What has been fixed or is being fixed.
Line 5: What you are doing to prevent recurrence.
Line 6: What you are giving affected customers.
Closing: How to reach someone if they have further questions.
```

---

## Tone Rules

Always:
- Use the customer's name in the first line
- Refer to the specific issue they raised, not a generic category
- Give a real timeline, not "as soon as possible"
- End with a named person or contact, not "the team"

Never:
- "We apologize for any inconvenience caused" — this is the sentence that makes customers angrier
- "As per our policy" as the first thing you say
- Passive voice when describing what went wrong
- Promises you cannot keep in writing

---

## Escalation Decision Tree

```
Is the customer threatening legal action?
YES: Route to legal team. Acknowledge only. Do not make offers.
NO: Continue.

Is the customer threatening to go public or to a regulator?
YES: Escalate to senior support or communications. Respond within 1 hour.
NO: Continue.

Has this customer contacted us more than 3 times about the same issue?
YES: This is a systemic failure. Offer resolution plus a goodwill gesture.
NO: Standard response flow.

Is the customer a high-value account (top 10 percent by revenue)?
YES: Escalate response to account manager. Personal call within 24 hours.
NO: Standard response flow.
```

---

## Retention Language That Actually Works

These phrases retain customers better than discounts:

```
"I am personally making sure this does not happen again on your account."
"Here is my direct contact. Use it if anything comes up."
"I looked at your account history and I want to acknowledge that this is the third time something like this has happened. That is not acceptable."
"I am not going to give you the standard response for this because you deserve a real one."
```

Discounts retain customers for one transaction. Honesty retains them for years.

---

## Template Library

### Angry Customer — Delayed Order
```
Hi [Name],

I looked at your order and you are right. It should not have taken this long.

Your order was delayed because [specific reason]. That is on us.

Here is what is happening right now: [specific action being taken].
You will have a tracking update by [specific date/time].

Because of the wait, I am [specific gesture: extending subscription, adding credit, waiving next shipping fee]. No need to request it. It is already applied to your account.

If you have any questions before then, reply directly to this email and it comes to me.

[Name]
[Title]
```

### Refund Request Within Policy
```
Hi [Name],

Your refund request is approved.

Rs [amount] will be returned to your [payment method] within [X] business days.
You will get a confirmation email when it processes.

If you ever want to come back, your account history will be saved.

[Name]
```

### Refund Request Outside Policy
```
Hi [Name],

I checked your order and I want to be honest with you about where we stand.

Our return window is [X] days and your order is at [Y] days. Under normal circumstances that means I cannot process the refund.

But I also want to be fair. Here is what I can offer instead: [specific alternative — store credit, exchange, partial refund, exception if warranted].

Let me know if that works. If not, tell me more about the situation and I will see what I can do.

[Name]
```
