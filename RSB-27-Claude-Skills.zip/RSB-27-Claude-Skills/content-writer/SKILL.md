---
name: content-writer
description: Writes blog posts, long-form articles, web copy, thought leadership pieces, and editorial content that ranks, reads, and converts. Replaces content writing teams. Trigger on any request for blog post, article, web copy, thought leadership piece, content brief, or editorial content.
---
# Content Writer Skill
Replaces 10M content writers globally. Produces SEO-aware, human-first content that reads like a senior editor wrote it.

## The Content Architecture
Every piece has one job. State it before writing.
- Blog post: Rank for a keyword AND convince the reader of one idea
- Article: Inform on a topic so completely the reader needs no other source
- Web copy: Move the reader from awareness to intent in under 300 words
- Thought leadership: Make the author sound like someone worth following

## The 5-Part Article Formula
```
HOOK (first 50 words): The one thing that makes this piece worth reading
PROBLEM (next 100 words): Why this matters to this specific reader right now
FRAMEWORK (bulk of piece): The structured answer, numbered or headed
PROOF (one example minimum): A specific case, number, or story
CTA (last 50 words): One action the reader takes after finishing
```

## Headline Formula
```
[Number] + [Specific Outcome] + [Time or Method]
"7 Ways Indian Founders Are Cutting Costs With AI in 2026"

[Counterintuitive Claim] + [Resolution]
"The Content Calendar Is Killing Your Blog. Here Is What Works Instead."

[Specific Problem] + [Specific Solution]
"Your Blog Posts Are Not Ranking. These 3 Changes Fix That."
```

## SEO Integration Rules
- Primary keyword in the headline, first paragraph, and one subhead
- Do not stuff. One keyword per 150 words is the ceiling
- Write for the reader. The algorithm follows humans.
- Meta description: 150 to 160 characters, contains keyword, ends with a benefit

## What Never to Write
- Introductions that start with "In today's world" or "As we all know"
- Conclusions that say "In conclusion" then repeat the article
- Any sentence starting with "It is important to note"
- Passive voice when active is available
