---
name: performance-review-writer
description: Writes employee performance reviews, self-appraisals, 360-degree feedback summaries, promotion justifications, and performance improvement plans. Produces fair, specific, and legally defensible review documents. Trigger on any request for a performance review, appraisal, self-evaluation, 360 feedback, PIP, or promotion justification.
---
# Performance Review Writer Skill
Replaces 5M managers doing performance review documentation globally. Produces reviews that are fair, specific, and defensible.

## The Two Rules of Performance Reviews
Rule 1: Specific behaviour or outcome, never personality.
Rule 2: If you cannot put a number or example against it, do not say it.

Wrong: "She is a great team player and always positive."
Right: "She delivered the Q2 onboarding project 2 weeks ahead of schedule and trained 3 new team members without being asked."

## Performance Review Structure
```
EMPLOYEE: [Name] | ROLE: [Title] | REVIEW PERIOD: [Dates]
REVIEWER: [Name] | DATE: [Date]

OVERALL RATING: [Exceeds / Meets / Below expectations]
ONE-LINE SUMMARY: [The single most accurate sentence about this person's year]

ACHIEVEMENTS (3 to 5, specific):
1. [Achievement] — Impact: [what this produced for the business]
2. [Achievement] — Impact: [what this produced for the business]
3. [Achievement] — Impact: [what this produced for the business]

DEVELOPMENT AREAS (2 to 3, specific and constructive):
1. Area: [what needs to improve]
   Example: [specific instance where this showed up]
   Support available: [what the company or manager will provide]
   
GOALS FOR NEXT PERIOD:
Goal 1: [Specific, measurable, time-bound]
Goal 2: [Specific, measurable, time-bound]
Goal 3: [Specific, measurable, time-bound]

COMPENSATION RECOMMENDATION:
[Increase / No change / Decrease] — Justification: [one sentence]
```

## Writing Feedback That Is Legally Defensible
Always:
- Use observed behaviour, not inferred character
- Include dates and specific examples
- Be consistent — if you note something for one employee, apply the same standard to all

Never:
- Reference personal characteristics (age, health, family, religion, gender)
- Use words like "attitude problem" — describe the behaviour instead
- Give a negative rating with no documented prior discussion
- Give a positive rating to avoid conflict — this creates legal risk if termination follows

## Self-Appraisal Prompts
Help employees write honest, strong self-appraisals with these questions:
```
1. What is the one outcome you are most proud of this year? What did you do specifically?
2. What is the biggest challenge you faced? How did you respond?
3. What did you learn this year that changed how you work?
4. Where did you fall short of what you intended? What would you do differently?
5. What do you need more of to perform better next year?
```

## Promotion Justification Formula
```
[Name] is ready for [next level] based on evidence across three dimensions:

SCOPE: [Current scope] to [target scope]. Already operating at this level by [example].
IMPACT: [Specific business result attributable to their work].
READINESS: [What they have done that demonstrates readiness for the next level responsibilities].

Comparative context: [How they compare to others at current level and those recently promoted].

Risk of not promoting: [What happens if this person is not recognised].
```
