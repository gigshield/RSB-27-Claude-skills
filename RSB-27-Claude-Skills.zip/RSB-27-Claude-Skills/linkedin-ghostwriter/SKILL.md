---
name: linkedin-ghostwriter
description: Writes LinkedIn posts, articles, carousels, profile content, and thought leadership pieces for founders, executives, and personal brands. Captures voice, applies platform-native formatting, and produces content that builds authority and generates leads. Trigger on any request for a LinkedIn post, LinkedIn article, LinkedIn carousel, LinkedIn profile content, executive thought leadership, or personal brand content for LinkedIn.
---
# LinkedIn Ghostwriter Skill
Replaces 2M LinkedIn content creators, ghostwriters, and social media managers globally. Writes LinkedIn content that sounds like the named person and performs on the platform.

## Voice Capture Protocol
Before writing anything, establish the person's voice from 3 inputs:
1. A post they wrote themselves that performed well
2. How they speak in an interview or video
3. The one topic they genuinely care about most

From these inputs extract:
- Sentence length preference (short punchy vs longer analytical)
- Vocabulary level (plain vs technical)
- Personal disclosure comfort (shares personal story vs stays professional)
- Opinion confidence (states views directly vs invites discussion)
- Humour and warmth level

Write every post so the named person could have typed it in their voice, not yours.

## LinkedIn Post Formula (RSB Edition)
```
LINE 1 — HOOK (under 12 words, no "see more" before this):
The claim, the number, the confession, or the counterintuitive statement.
Never start with "I" as the first word.
Never start with a greeting.

LINES 2 TO 3 — STAKES:
Why the person reading this should care. Specifically.
Connect to a fear, an aspiration, or a cost they recognise.

LINES 4 TO 12 — THE SUBSTANCE:
Numbered points, a story, or a framework.
One idea per line or per short paragraph.
White space is not weakness. Dense paragraphs get skipped.

LINE 13 — THE INSIGHT:
The one sentence that is bigger than the specific content.
This is what gets saved and shared.

LINE 14 — THE CTA:
One thing. Not three. The most important one.
```

## Post Types and When to Use Each

### The Story Post
Hook: A specific moment in time.
Body: What happened, what was discovered, what it means.
Use for: Emotional resonance, humanising the brand, high shares.

### The Framework Post
Hook: A counterintuitive claim or a specific number.
Body: The system, the steps, the method.
Use for: Saves, follows, authority building.

### The Opinion Post
Hook: A direct statement of a view that some will disagree with.
Body: The three reasons the view is correct.
Close: An honest acknowledgment of the other side.
Use for: Comments, discussion, positioning.

### The Case Study Post
Hook: The result, stated first.
Body: The situation, the action, the outcome.
Use for: Lead generation, proof of expertise.

### The Handraiser Post
Hook: A resource or tool offer.
Body: What it is and who it is for.
CTA: Comment X for the resource.
Use for: Email list building, DM conversations.
Note: Use sparingly. Twice per month maximum. More suppresses reach.

## Carousel Structure
```
SLIDE 1 — COVER:
The headline. Bold. One claim. One number.
Makes them swipe.

SLIDES 2 TO 8 — CONTENT:
One point per slide. Large text. Short sentences.
Each slide works standalone — someone who screenshots one slide gets the point.

SLIDE 9 — THE SUMMARY:
The 3 things they should remember.
Not a repetition — an elevation of the key insight.

SLIDE 10 — THE CTA:
Follow for more. Save this. Link in bio.
One action only.
```

## What Kills LinkedIn Reach
- Posting at irregular intervals (inconsistency signals to the algorithm)
- External links in the post body (LinkedIn suppresses them — put in first comment)
- Long paragraphs with no line breaks
- No engagement in the first 60 minutes after posting
- Generic CTAs like "like and share if you agree"
- Posting and disappearing — reply to every comment in the first hour

## Ghostwriting Disclosure
Note when producing content for another person: the goal is that nobody should be able to tell it was ghostwritten. If it sounds like it was written by a service rather than a person, rewrite it until it sounds like one specific human with one specific point of view.
