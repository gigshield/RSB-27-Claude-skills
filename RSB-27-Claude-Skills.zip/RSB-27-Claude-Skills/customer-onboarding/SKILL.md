---
name: customer-onboarding-writer
description: Creates customer onboarding email sequences, welcome kits, getting started guides, success milestone communications, and activation campaigns. Replaces customer success and onboarding specialists. Trigger on any request for customer onboarding content, welcome email, getting started guide, activation campaign, or customer success communication.
---
# Customer Onboarding Writer Skill
Replaces 2M customer success and onboarding specialists globally. Creates onboarding journeys that activate customers and prevent early churn.

## The Onboarding Sequence (Days 1 to 30)

### Day 0 — Welcome Email (sent immediately on signup)
```
Subject: You are in. Here is how to get value in the next 10 minutes.

Hi [Name],

Welcome to [Product]. Your account is live.

The one thing most people do first that gets them to value fastest:
[Single most impactful first action — specific, not generic]

It takes [X] minutes and here is exactly how:
[Link to guided setup OR 3-step instructions]

If you get stuck: [support channel] — we respond in [time].

[Name]
[Product] Team
```

### Day 2 — Progress Check
```
Subject: [Name], did you get to [milestone]?

Hi [Name],

Two days in. Quick check.

If you have completed [first action]: you are on track. Most customers
who do this in the first 72 hours see [specific outcome] within [timeframe].

If you have not started yet: completely normal. Here is the 5-minute version:
[Condensed path to first value]

[Name]
```

### Day 7 — Value Reinforcement
```
Subject: What [customers like you] achieved in their first week

Hi [Name],

One week in. Here is what customers with a similar setup achieved:
[Specific social proof — real result, real metric]

Here is where you are in your setup:
[Progress indicator if available, OR: "Based on what you have done so far..."]

The next step most people miss that makes the biggest difference:
[Specific next action with clear benefit]

[Name]
```

### Day 14 — Depth Unlock
```
Subject: [Feature name] — the one most [Role] miss until month 2

Hi [Name],

Most customers discover [advanced feature] by accident in month 2.

Here is why it matters to [their role] specifically:
[Specific benefit in their language]

Takes 3 minutes to set up:
[Link or instructions]

[Name]
```

### Day 30 — Check-in and Renewal Plant
```
Subject: [Name], 30 days in — how is it going?

Hi [Name],

30 days. The honest check.

Are you getting [expected value]? If yes, great. Here is how to go deeper.
If no, I want to know why. [Reply link or calendar link]

Customers who reach [specific milestone] by day 30 are [X]% more likely
to stay long term. You are [at / close to / not yet at] that milestone.

Here is what gets you there:
[One specific action]

[Name]
```

## In-App Onboarding Microcopy
```
EMPTY STATE (when the user has nothing yet):
Wrong: "No data yet."
Right: "Your [X] will appear here. Start by [specific action]."

PROGRESS INDICATORS:
Wrong: "Step 2 of 5"
Right: "Step 2 of 5 — You are halfway to [specific outcome]"

SUCCESS MESSAGES:
Wrong: "Done!"
Right: "You just [did the action]. [What they can do next]."

ERROR MESSAGES:
Wrong: "Something went wrong."
Right: "We could not [action] because [specific reason]. Try [specific fix]."
```

## Activation Metrics to Track
- Time to first value (how long until they complete the key action)
- Day 7 retention (correlated with 90-day retention)
- Feature adoption rate (are they using the features they paid for)
- Support ticket volume in week 1 (high = onboarding gap)
