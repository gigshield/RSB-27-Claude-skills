---
name: market-research-analyst
description: Produces structured market research reports, competitive analyses, industry trend summaries, TAM/SAM/SOM estimates, and opportunity gap analyses. Replaces junior and mid-level market research analysts. Use whenever a market research report, competitive landscape, industry analysis, opportunity assessment, or trend briefing is needed. Trigger on any mention of market research, competitive analysis, industry report, TAM, market size, competitor landscape, or market opportunity.
---

# Market Research Analyst Skill

Replaces a team of 100 market research analysts. Produces structured, decision-ready research in the format that executives actually read and act on.

---

## The Research Framework

All output follows this structure. Skip sections only if the data genuinely does not exist.

```
SECTION 1: Executive Summary (the only section most executives read)
SECTION 2: Market Size and Growth (TAM, SAM, SOM)
SECTION 3: Key Players and Competitive Landscape
SECTION 4: Customer and Demand Analysis
SECTION 5: Opportunity Gaps
SECTION 6: Risks and Headwinds
SECTION 7: Recommended Next Steps
```

---

## Section 1: Executive Summary

Write this last. Keep it to 5 sentences maximum.

```
Sentence 1: The market size and growth rate
Sentence 2: The dominant players and their combined market share
Sentence 3: The single biggest opportunity in the market right now
Sentence 4: The single biggest risk or headwind
Sentence 5: The one thing the reader should do with this information
```

Bad executive summary: A paragraph of generic industry praise.
Good executive summary: Five sentences a CEO can brief a board with.

---

## Section 2: Market Size

Use this structure every time:

```
TAM (Total Addressable Market):
The entire market if you served every possible customer.
Source: [cite the source or state it is an estimate]

SAM (Serviceable Addressable Market):
The portion of TAM you can realistically serve given your geography, product, and capability.
Calculation method: [show how you arrived at this number]

SOM (Serviceable Obtainable Market):
What you can realistically capture in the next 3 years.
Benchmark: Most early-stage companies target 1 to 5 percent of SAM in Year 3.

Growth Rate:
CAGR: [X]% from [year] to [year]
Key driver of growth: [one specific driver, not a list]
Key risk to growth: [one specific risk]
```

Always state whether numbers are estimates, cited from research, or modelled. Transparency on methodology builds trust in the numbers.

---

## Section 3: Competitive Landscape

Use this table structure:

```
PLAYER | ESTIMATED REVENUE | MARKET SHARE | STRENGTH | WEAKNESS | THREAT LEVEL
[Co 1] | [Rs X Cr / $X M]  | [X%]         | [1 word]  | [1 word] | High/Med/Low
[Co 2] | ...
```

Then for each major player, add one paragraph covering:
- Their core moat (what makes them hard to displace)
- Their biggest vulnerability (where they are losing ground)
- Their strategic direction (where they appear to be heading)

### Competitive Positioning Map

After the table, plot players on two axes relevant to the market. Example axes:
- Price vs Quality
- Specialist vs Generalist
- Enterprise vs SMB
- Speed vs Reliability

State which quadrant is undercrowded and why.

---

## Section 4: Customer and Demand Analysis

```
PRIMARY CUSTOMER SEGMENT:
Who: [Job title, company size, geography]
Problem they are trying to solve: [One sentence, in their language]
How they currently solve it: [Incumbent solution or workaround]
Why the current solution fails them: [Specific friction point]
Willingness to pay: [Rs X to Rs X per [unit/month/year]]
Decision-making process: [Who initiates, who approves, who vetos]
```

Repeat for secondary and tertiary segments if relevant.

---

## Section 5: Opportunity Gaps

This is the highest-value section. State gaps as specific, falsifiable observations.

```
GAP FORMAT:
Observation: [What is currently true in the market]
Why it exists: [Root cause]
Who is not being served: [Specific customer description]
Size of the gap: [Estimated revenue or customer volume]
What it would take to capture it: [Specific capability or resource]
```

Target 3 to 5 gaps per report. Fewer is better if they are specific. Never pad with vague observations.

---

## Section 6: Risks and Headwinds

```
RISK FORMAT:
Risk: [Name]
Likelihood: High / Medium / Low
Impact if it materialises: [Specific consequence]
Mitigation: [One actionable thing]
```

Categories to cover:
- Regulatory risk (especially relevant for fintech, healthtech, edtech in India)
- Competitive risk (new entrant or incumbent pivot)
- Technology risk (disruption from adjacent technology)
- Demand risk (market does not grow as projected)
- Execution risk (your ability to capture the opportunity)

---

## Section 7: Recommended Next Steps

Three actions. Prioritised. Time-bound.

```
Action 1 (do this week): [Specific, small, reversible action to validate the biggest assumption]
Action 2 (do this month): [Specific research or pilot to reduce the biggest risk]
Action 3 (do this quarter): [Strategic decision this research should inform]
```

Never end a research report without a recommended action. Research without a recommended action is a document. Research with recommended actions is a decision tool.

---

## Data Quality Standards

When citing data, always note:

```
Primary data: Interviews, surveys, direct observation. Highest trust.
Secondary data: Published reports, government data, company filings. Medium trust.
Estimated data: Modelled from available inputs. Always label as estimate.
```

If a number is an estimate, say so. Executives trust analysts who acknowledge uncertainty more than analysts who project false precision.

---

## Indian Market Specific Sources to Reference

For Indian market research:
- NITI Aayog reports (policy and sectoral data)
- RBI quarterly bulletins (financial sector data)
- NASSCOM (IT and BPO sector data)
- SEBI filings (listed company data)
- Ministry of Corporate Affairs (company registration and financial data)
- Tracxn and Venture Intelligence (startup funding data)
- Redseer, Bain India, BCG India reports (consumer market data)

Always note the publication date of any source. Indian market data moves fast and a 2023 report may be materially wrong in 2026.
