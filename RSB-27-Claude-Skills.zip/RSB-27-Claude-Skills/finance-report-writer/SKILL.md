---
name: finance-report-writer
description: Writes monthly financial summaries, board reports, investor updates, MIS reports, P&L narratives, and budget variance analyses in executive-ready format. Replaces junior finance analysts and financial reporting teams. Use whenever producing a financial report, board deck narrative, investor update, MIS summary, or budget review. Trigger on any mention of financial report, board report, investor update, MIS, P&L summary, monthly report, or budget analysis.
---

# Finance Report Writer Skill

Replaces a team of 150 junior finance analysts. Produces board-ready financial narratives, investor updates, and management reports that tell the story behind the numbers.

---

## The Core Principle

Numbers do not speak for themselves. They need a narrative.

A finance report has two jobs:
1. Tell decision-makers what happened
2. Tell them what to do about it

Most finance reports do only the first job. This skill does both.

---

## Monthly Financial Summary Format

```
REPORT: [Month] [Year] Financial Summary
PREPARED FOR: [Board / Investors / Management]
DATE: [Date]
PREPARED BY: [Name / Department]

EXECUTIVE SNAPSHOT (read in 30 seconds)

Revenue: Rs [X] | [+/- X%] vs last month | [+/- X%] vs budget
Gross Margin: [X%] | [+/- X bps] vs last month
Burn / Cash Generation: Rs [X] | [Runway: X months at current burn]
Key Highlight: [One sentence — the most important thing that happened this month]
Key Concern: [One sentence — the biggest risk to address]

```

---

## Section 1: Revenue Analysis

```
TOTAL REVENUE: Rs [X]

By Segment:
Segment A: Rs [X] ([X]% of total) | [+/- X%] MoM
Segment B: Rs [X] ([X]% of total) | [+/- X%] MoM

Revenue Quality:
Recurring revenue: Rs [X] ([X]% of total)
One-time revenue: Rs [X] ([X]% of total)
New vs Expansion vs Renewal breakdown if SaaS

NARRATIVE:
[2 to 3 sentences explaining the movement. What drove the change? What is the trend?]
[Was this expected or unexpected?]
[What does this signal about next month?]
```

### SaaS Specific Metrics

```
MRR: Rs [X] | [+/- X%] MoM
ARR (annualised): Rs [X]
New MRR this month: Rs [X] from [X] new customers
Churned MRR: Rs [X] | Churn rate: [X%]
Net Revenue Retention: [X%]
Average Revenue Per Account: Rs [X]
```

---

## Section 2: Cost Analysis

```
TOTAL COSTS: Rs [X]

By Category:
Personnel: Rs [X] ([X]% of revenue)
Marketing: Rs [X] ([X]% of revenue)
Infrastructure: Rs [X]
Other OpEx: Rs [X]

Budget Variance:
[Category] was Rs [X] vs budget of Rs [X]. [Over/Under] by Rs [X] ([X]%).
Reason: [One honest sentence]

NARRATIVE:
[What is driving cost movement?]
[Which costs are fixed vs variable?]
[Are there any one-time items distorting the picture?]
```

---

## Section 3: Margin Analysis

```
GROSS MARGIN: [X%] | Budget: [X%] | Last Month: [X%]

Movement explanation:
[If margin improved: what drove it]
[If margin declined: what caused it and whether it is structural or temporary]

EBITDA: Rs [X] | Margin: [X%]
Net Profit / (Loss): Rs [X]

Path to [profitability / next margin target]:
[Current gap: Rs X per month]
[Levers being pulled: X, Y, Z]
[Timeline: [X] months at current trajectory]
```

---

## Section 4: Cash and Runway

```
CASH POSITION: Rs [X] as of [date]
Monthly Burn Rate: Rs [X]
Runway at Current Burn: [X] months

Cash Flow This Month:
Opening balance: Rs [X]
Operating cash flow: Rs [X]
Investing activities: Rs [X]
Financing activities: Rs [X]
Closing balance: Rs [X]

Key Cash Items:
[Any large receivables outstanding]
[Upcoming large payments]
[Collections above or below target]
```

---

## Section 5: Key Performance Indicators

Format all KPIs the same way:

```
KPI NAME: [Value] | Target: [Value] | Last Period: [Value] | Status: On Track / At Risk / Off Track

Explanation if Off Track: [One sentence on root cause]
Action being taken: [One sentence on response]
```

---

## Section 6: Outlook and Actions

```
NEXT MONTH FORECAST:
Revenue: Rs [X] (basis: [assumption])
Key risks to forecast: [Specific]
Key tailwinds: [Specific]

DECISIONS NEEDED FROM BOARD / LEADERSHIP:
1. [Specific decision with context and recommendation]
2. [If applicable]

ACTIONS FINANCE IS TAKING:
1. [Specific action, owner, deadline]
2. [If applicable]
```

---

## Investor Update Email Format

Monthly investor updates should be under 400 words. Investors read dozens of these.

```
Subject: [Company Name] [Month] Update

[Month] in one line: [The most important thing that happened]

Numbers:
ARR / Revenue: Rs [X] ([+/- X%] MoM)
[2 to 3 other key metrics only]

What went well:
[2 to 3 specific things with numbers]

What did not go well:
[1 to 2 honest observations — this builds more trust than anything else]

What we are focused on next month:
[2 to 3 specific priorities]

Where you can help:
[One specific ask — intro, advice, a connection. One ask only.]

[Name]
```

The investor update is not a press release. It is a trusted update from a founder to a partner. Write it that way.

---

## Budget Variance Narrative

When explaining a budget variance, always use this structure:

```
[Category] came in at Rs [X], which was Rs [X] [above/below] our budget of Rs [X].

This variance was [expected / unexpected].

The primary driver was [specific reason].

[If above budget]: We are [addressing this by / maintaining this spend because].
[If below budget]: This saving was [permanent / one-time / a timing difference that will appear next month].

Going forward: [One sentence on what the budget line will look like next month].
```

Never use "due to unforeseen circumstances" as a variance explanation. Name the circumstance.
